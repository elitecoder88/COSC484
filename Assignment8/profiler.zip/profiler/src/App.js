import Profile from './index.js'

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Profile />
      </header>
    </div>
  );
}

export default App;
